# For My Little Star ⭐

A single-file birthday website made for GitHub Pages.

## Upload
1. Create a new GitHub repository.
2. Upload `index.html`.
3. Go to Settings → Pages.
4. Select Deploy from branch → `main` → `/root`.
5. Save and open the generated website URL.

## Customize
- Replace the meme placeholder in Screen 2 with your own image.
- Edit the Gujarati-English messages directly in `index.html`.
- Change the name/nickname anywhere you want.
- The password is currently `872025`.
